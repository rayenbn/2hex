$(document).ready(function(){
  $('input[type="file"]').change(function(){
      var formData = new FormData();
      formData.append('file', $(this)[0].files[0]);
      self = this;
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
      $.ajax({
             url : 'configurator-fileupload',
             type : 'POST',
             data : formData,
             processData: false,  // tell jQuery not to process the data
             contentType: false,  // tell jQuery not to set contentType
             success : function(data) {
                 if(data != 'failed')
                    $(self).attr('filename','data');
             }
      });
  });
});
  
