<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ConfiguratorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('configurator');
    }
    public function store(Request $request)
    {
        var_dump($request);
        exit();
    }
    public function upload(Request $request)
    {
        if($request->hasFile('file')) {
           $file = $request->file('file');
           
           //you also need to keep file extension as well
           $name = uniqid(rand(), true).'.'.$file->getClientOriginalExtension();;
            
           //using the array instead of object
           
           $file->move(public_path().'/uploads/', $name);
           return $name;
        }
        return 'failed';
    }
}
