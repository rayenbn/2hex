<!-- begin::Quick Sidebar -->
<div id="m_quick_sidebar" class="m-quick-sidebar m-quick-sidebar--tabbed m-quick-sidebar--skin-light" style="padding:0;">
    <div class="m-quick-sidebar__content m--hide" style="height:100%;">
        <span id="m_quick_sidebar_close" class="m-quick-sidebar__close"><i class="la la-close"></i></span>
        <ul id="m_quick_sidebar_tabs" class="nav nav-tabs m-tabs m-tabs-line m-tabs-line--brand" role="tablist" style="margin:0;height:50px;">
            <li class="nav-item m-tabs__item">
                <a class="nav-link m-tabs__link active" data-toggle="tab" href="#m_quick_sidebar_tabs_messenger" role="tab" style="margin-left:30px;">Support Chat</a>
            </li>
        </ul>
        <div style="height: calc(100% - 60px);">
            <iframe height="100%" width="100%" style="margin:0px;" src="https://tawk.to/chat/5c702860a726ff2eea59008f/default" frameborder="0" allow="autoplay; fullscreen; vr" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
        </div>
    </div>
</div>

<!-- end::Quick Sidebar -->