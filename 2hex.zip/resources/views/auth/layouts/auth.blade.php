@extends('layouts.auth')

@section('page')

    {{--Region Content--}}
    @yield('content')
    
@endsection

